/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jloic2;

/**
 *
 * @author Administrator
 */
public class AttackStats {
    long PacketsSent;
    double KbitsSent;
    double PksPerSec;
    double KbitPerSec;
}
